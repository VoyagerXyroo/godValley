self.__SSG_MANIFEST = new Set([
  "\u002F",
  "\u002F[uid]",
  "\u002Fa-propos",
  "\u002Fpartenaires\u002F[uid]",
  "\u002Fprojets\u002F[uid]",
]);
self.__SSG_MANIFEST_CB && self.__SSG_MANIFEST_CB();
